[Love press++: Massage for your truelove OpenBeta1]

[Crated by]	Shirai Laboratory, Department of Information Media,
		 Faculty of Information Technology, KAIT (Kanagawa Institute of Technology) in Japan
[Created at]	September 9 ,2010
[Contact]	oreyome@shirai.la
[HP]		http://www.shirai.la/project/lovepress

[What is it?]
This project is applied for Sense of Wonder Night in Tokyo Game Show 2010.
http://expo.nikkeibp.co.jp/tgs/2010/sown/
Please find details on this page:
http://www.shirai.la/project/lovepress
Or, this YouTube video make you fun to understand our project:


[Environment] These environment must be installed beofre,
Microsoft XNA Framework Redistributable 3.1
http://www.microsoft.com/downloads/details.aspx?FamilyID=53867a2a-e249-4560-8011-98eb3e799ef2&displaylang=en
Microsoft .NET Framework Version 2.0

[Hardwares]
-Wii Balance Board
-Bluetooth USB Adaptor

If you need help for Bluetooth connection to your PC, please see,
http://akihiko.shirai.as/projects/WiiRemote/chapter2.php

Here is a kind book "WiiRemote Programming"
http://bit.ly/WiiRemote
It can be recommended who want to create such a game system using Balance Wii Board and Wiimotes.


[How to try]
please try to run "OreYome_Beta2.exe" after the Bluetooth paring connection.
If you don't have any Balance Wii Board, It plays pre-recorded data to show a demo.

Let's do massage Balance Board to resemble your truelove's back shot by "your best service mind".
If she feel good, she may reply you by various voice reactions.

This version contains some hidden functions cause a beta version.
If you have any interest to improve better recognition and game play, give your feed back please.
("result.csv" in data folder has your playing data)

[Attention]
This program has no garranty. And it may contain difference with the final version.
If this program cause any prejudice, damnification, especially, complaint from your partner who have find the suspicious voice and interactions :-p
All right are held by Shirai Lab. Contact us if you would like to distribute or report about this article.

Voice data have been provided by "pecora", we thank her participation and please don't distribute her voice data illegally from this project.

LovePress++ Project Team: oreyome@shirai.la

