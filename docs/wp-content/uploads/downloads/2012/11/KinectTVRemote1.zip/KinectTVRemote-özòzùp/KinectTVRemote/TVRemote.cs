﻿using System;
using System.Windows.Forms;

// 指定しておく
using Microsoft.Win32.SafeHandles;

// USBリモコンのdll
using USB_IR_Library;

namespace KinectTVRemote
{
    public class TVRemote
    {
        /// <summary>
        /// USBのデバイス
        /// </summary>
        private SafeFileHandle usbDevice = null;
        
        // 赤外線コード
        // sharpのテレビの場合
        // 赤外線のコードは「赤外線リモコンキット」のサンプルプログラムで確認できる
        private byte[] code0 = { 0xaa, 0x5a, 0x8f, 0x12, 0x75, 0xb2 }; // 裏番組
        private byte[] code1 = { 0xaa, 0x5a, 0x8f, 0x12, 0x57, 0x81 }; // ↑ボタン
        private byte[] code2 = { 0xaa, 0x5a, 0x8f, 0x12, 0x52, 0xd1 }; // 決定
        private byte[] code3 = { 0xaa, 0x5a, 0x8f, 0x12, 0x20, 0x81 }; // ↓ボタン

        /// <summary>
        /// USBの状態
        /// </summary>
        private int i_ret = 0;

        /// <summary>
        /// 前フレームの姿勢状態
        /// </summary>
        private int oldMotionType = 100; // HnadKeepが0のため、初期値は100とした


        ////////////////////////

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TVRemote(IntPtr Handle)
        {
            // USBデバイスオープン
            usbDevice = USBIR.openUSBIR(Handle);
        }

        /// <summary>
        /// 送信処理
        /// </summary>
        public void Transmission(int motionType)
        {
            // 前フレームと同じだった場合処理をしない
            if (oldMotionType != motionType)
            {
                switch (motionType)
                {
                    case 1:
                        i_ret = USBIR.writeUSBIR(usbDevice, USBIR.IR_FORMAT.AEHA, code1, 48);
                        break;

                    case 2:
                        i_ret = USBIR.writeUSBIR(usbDevice, USBIR.IR_FORMAT.AEHA, code2, 48);
                        break;

                    case 3:
                        i_ret = USBIR.writeUSBIR(usbDevice, USBIR.IR_FORMAT.AEHA, code3, 48);
                        break;

                    case 4:
                        i_ret = USBIR.writeUSBIR(usbDevice, USBIR.IR_FORMAT.AEHA, code0, 48);
                        break;

                    case 0:
                    default:
                        break;
                }
            }

            // 現フレームの姿勢状態を保存
            oldMotionType = motionType;
        }

        /// <summary>
        /// 終了処理
        /// </summary>
        public void Dispose()
        {
            // USB DEVICEクローズ
            i_ret = USBIR.closeUSBIR(usbDevice);
        }

    }
}
