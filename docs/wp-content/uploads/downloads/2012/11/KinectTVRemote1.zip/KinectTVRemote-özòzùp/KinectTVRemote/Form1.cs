﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Bitmapを生成するため
using System.Drawing.Imaging;

// メモリ管理の最適化のため？
using System.Runtime.InteropServices;

// Microsoft.Kinectを参照しておく
using Microsoft.Kinect;

// 自作の[Vector3]を利用するため
using AccuMotion;

namespace KinectTVRemote
{
    #region -- struct --

    /// <summary>
    /// 画面上で表示する骨格の位置情報
    /// </summary>
    public struct Vector2
    {
        /// <summary>
        /// 画面上でのX座標
        /// </summary>
        public int X { get; set; }

        /// <summary>
        /// 画面上でのY座標
        /// </summary>
        public int Y { get; set; }
    }

    ///// <summary>
    ///// Kinectで取得した実空間での座標
    ///// </summary>
    //public struct Vector3
    //{
    //    /// <summary>
    //    /// Kinectで取得した実空間でのX座標
    //    /// </summary>
    //    public float X { get; set; }

    //    /// <summary>
    //    /// Kinectで取得した実空間でのY座標
    //    /// </summary>
    //    public float Y { get; set; }

    //    /// <summary>
    //    /// Kinectで取得した実空間でのZ座標
    //    /// </summary>
    //    public float Z { get; set; }
    //}

    #endregion

    public partial class Form1 : Form
    {
        /// <summary>
        /// Kinectのセンサクラス
        /// </summary>
        private KinectSensor kinect;

        #region -- カラー画像に必要な変数 --

        /// <summary>
        /// Kinectから取得したRGBデータ
        /// (byte配列)
        /// </summary>
        private byte[] colorImageData;

        /// <summary>
        /// カラー画像のビットマップ
        /// </summary>
        private Bitmap colorImageBitmap;

        #endregion

        #region -- 深度画像に必要な変数 --

        /// <summary>
        /// 深度データを変換した色情報
        /// (byte配列)
        /// </summary>
        private byte[] depthImageData;

        /// <summary>
        /// 深度画像のビットマップ
        /// </summary>
        private Bitmap depthImageBitmap;

        /// <summary>
        /// 認識ユーザごとにつける色
        /// </summary>
        static readonly int[] PlayerR = { 1, 2, 0, 2, 0, 0, 2, 0 },
                              PlayerB = { 1, 2, 2, 0, 2, 0, 0, 1 },
                              PlayerG = { 1, 0, 2, 2, 0, 2, 0, 2 };

        /// <summary>
        /// depthImageDataに色情報を挿入する順番
        /// (BGRAの順で格納される)
        /// </summary>
        const int RedIndex = 2, GreenIndex = 1, BlueIndex = 0;

        #endregion

        #region -- 骨格情報に必要な変数 --

        /// <summary>
        /// 骨格情報
        /// </summary>
        private Skeleton[] skeletonData;

        /// <summary>
        /// 画像で表示する骨格の位置
        /// </summary>
        private Vector2[] skeletonPosition2D;

        /// <summary>
        /// Kinectで取得した実空間での位置
        /// </summary>
        private Vector3[] skeletonPosition3D;

        #endregion

        /// <summary>
        /// 姿勢の状態を認識
        /// </summary>
        private MotionRecognition motionRecognition;

        /// <summary>
        /// 赤外線リモコンキットによるTV操作
        /// </summary>
       private TVRemote tvRemote;


        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Formが読み込まれるときの処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Kinectが1台以上接続されているか
                if (KinectSensor.KinectSensors.Count == 0)
                    throw new Exception("Kinectが1台も接続されていません");

            }
            catch (Exception ex)
            {
                // ダイアログボックスで起動失敗を表示し終了
                if (MessageBox.Show(ex.Message) == DialogResult.OK)
                    this.Close();
            }

            // Kinectセンサの起動
            kinect = KinectSensor.KinectSensors[0];

            // カラー画像の設定
            kinect.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
            kinect.ColorFrameReady += new EventHandler<ColorImageFrameReadyEventArgs>(kinect_ColorFrameReady);

            // Bitmapのサイズ指定(カラー画像の縦横サイズを指定)
            colorImageBitmap = new Bitmap(kinect.ColorStream.FrameWidth, kinect.ColorStream.FrameHeight);


            // 深度画像の設定
            kinect.DepthStream.Enable(DepthImageFormat.Resolution320x240Fps30);
            kinect.DepthFrameReady += new EventHandler<DepthImageFrameReadyEventArgs>(kinect_DepthFrameReady);

            // Bitmapのサイズ指定（深度画像の縦横サイズを指定）
            depthImageBitmap = new Bitmap(kinect.DepthStream.FrameWidth, kinect.DepthStream.FrameHeight);

            // 骨格情報の設定
            kinect.SkeletonStream.Enable();
            kinect.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(kinect_SkeletonFrameReady);

            // skeletonPosition2Dの初期化
            skeletonPosition2D = new Vector2[20];

            // skeletonPosition3Dの初期化
            skeletonPosition3D = new Vector3[20];

            // Kinectの使用開始
            kinect.Start();

            // タイマーの起動
            timer1.Start();

            // motionRecognitionの初期化
            motionRecognition = new MotionRecognition();
            motionRecognition.AllLoadFile();

            // tvRemoteの初期化
            tvRemote = new TVRemote(this.Handle);
        }

        /// <summary>
        /// Formが閉じられるときの処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Kinectが1台以上接続されている場合
            if (KinectSensor.KinectSensors.Count != 0)
            {
                // Kinectのセンサ停止
                kinect.Stop();

                // イベントハンドラを削除
                kinect.ColorFrameReady -= kinect_ColorFrameReady;
                kinect.DepthFrameReady -= kinect_DepthFrameReady;

                // クラスの削除
                kinect.Dispose();
            }

            // timer1の停止
            timer1.Stop();

            // timer1の削除
            timer1.Dispose();

            // tvRemoteの削除
            tvRemote.Dispose();
        }

        /// <summary>
        /// pictureBox1のペイントイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            // skeletonDataがnullでない場合処理する
            if (skeletonData != null)
            {
                // 骨格の位置に円を表示する
                for (int i = 0; i < skeletonPosition2D.Length; i++)
                    e.Graphics.FillEllipse(Brushes.Red, skeletonPosition2D[i].X - 5, skeletonPosition2D[i].Y - 5, 10, 10);
            }
        }

        /// <summary>
        /// タイマーのイベント処理
        /// （タイマーの更新頻度は30[ms]にしてある = 30[Fps]）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            // ここで姿勢認識のアルゴリズムを使う
            motionRecognition.Update(skeletonPosition3D, trackBar1.Value, trackBar2.Value, trackBar3.Value, trackBar4.Value, trackBar5.Value, trackBar6.Value);

            // 評価関数値をラベルに表示
            label11.Text = motionRecognition.evaluationValue[0].ToString();
            label12.Text = motionRecognition.evaluationValue[1].ToString();
            label13.Text = motionRecognition.evaluationValue[2].ToString();
            label14.Text = motionRecognition.evaluationValue[3].ToString();
            label15.Text = motionRecognition.evaluationValue[4].ToString();

            // トラックバーの値をラベルに表示
            label6.Text = "/ " + trackBar1.Value.ToString();
            label7.Text = "/ " + trackBar2.Value.ToString();
            label8.Text = "/ " + trackBar3.Value.ToString();
            label9.Text = "/ " + trackBar4.Value.ToString();
            label10.Text = "/ " + trackBar5.Value.ToString();

            // KeepTimeの表示
            label19.Text = trackBar6.Value.ToString();

            // 現在の姿勢状態を表示
            label17.Text = motionRecognition.motionType.ToString();

            // 操作姿勢によってTVを操作
            tvRemote.Transmission((int)motionRecognition.motionType);
        }

        /// <summary>
        /// ボタン1のクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            // HandKeep姿勢の骨格ベクトルを保存
            motionRecognition.SaveFile((int)MotionType.HandKeep);
        }

        /// <summary>
        /// ボタン2のクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            // HandUp姿勢の骨格ベクトルを保存
            motionRecognition.SaveFile((int)MotionType.HandUp);
        }

        /// <summary>
        /// ボタン3のクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            // HandRight姿勢の骨格ベクトルを保存
            motionRecognition.SaveFile((int)MotionType.HandRight);
        }

        /// <summary>
        /// ボタン4のクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            // HandDown姿勢の骨格ベクトルを保存
            motionRecognition.SaveFile((int)MotionType.HandDown);
        }

        /// <summary>
        /// ボタン5のクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            // HandLeft姿勢の骨格ベクトルを保存
            motionRecognition.SaveFile((int)MotionType.HandLeft);
        }


        ///////////// Kinectからデータを得るためのイベントハンドラ・関数 /////////////

        /// <summary>
        /// カラー画像のイベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void kinect_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            // ColorImageFrameを取得
            ColorImageFrame colorImageFrame = e.OpenColorImageFrame();

            // colorImageFrameがnullだった場合処理しない
            if (colorImageFrame != null)
            {
                // colorImageData配列を初期化
                colorImageData = new byte[colorImageFrame.PixelDataLength];

                // colorImageFrameのデータをcolorImageDataへコピーする
                colorImageFrame.CopyPixelDataTo(colorImageData);

                // colorImageData(byte配列)をBitmapへ変換する
                colorImageBitmap = toBitmap(colorImageData, colorImageFrame.Width, colorImageFrame.Height);

                // ピクチャーボックスへ反映
                pictureBox1.Image = colorImageBitmap;

                // ColorImageFrameを削除
                colorImageFrame.Dispose();
            }
        }

        /// <summary>
        /// 深度画像のイベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void kinect_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        {
            // DepthImageFrameを取得
            DepthImageFrame depthImageFrame = e.OpenDepthImageFrame();

            // depthImageFrameがnullだった場合処理しない
            if (depthImageFrame != null)
            {
                // depthData配列の宣言・初期化
                // Kinectから取得した深度データを保持する
                short[] depthData = new short[depthImageFrame.PixelDataLength];

                // depthImageData配列の初期化（横*縦*RGBA）
                depthImageData = new byte[depthImageFrame.Width * depthImageFrame.Height * 4];

                // depthImageFrameのデータをdepthDataへコピーする
                depthImageFrame.CopyPixelDataTo(depthData);

                // 深度ごとに色付けを行う
                ConvertDepthFrame(depthData, kinect.DepthStream);

                // depthImageData（byte配列）をBitmapへ変換する
                depthImageBitmap = toBitmap(depthImageData, depthImageFrame.Width, depthImageFrame.Height);

                // ピクチャーボックスへ反映
                pictureBox2.Image = depthImageBitmap;

                // depthImageFramwを削除
                depthImageFrame.Dispose();
            }
        }

        /// <summary>
        /// 骨格情報のイベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void kinect_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            // SkeletonFrameを取得
            SkeletonFrame skeletonFrame = e.OpenSkeletonFrame();

            // skeletonFrameがnullだった場合処理しない
            if (skeletonFrame != null)
            {
                // skeletonDataの初期化
                skeletonData = new Skeleton[skeletonFrame.SkeletonArrayLength];

                // skeletonFrameのデータをskeletonDataへコピーする
                skeletonFrame.CopySkeletonDataTo(skeletonData);

                foreach (var user in skeletonData)
                {
                    // 認識ユーザの骨格を追跡している場合処理する
                    if (user.TrackingState == SkeletonTrackingState.Tracked)
                    {
                        // 骨格を取得する箇所（20箇所）
                        int jointIndex = 0;

                        // 骨格の各箇所の情報を取得する
                        foreach (Joint join in user.Joints)
                        {
                            // カラー画像のサイズに合わせて骨格情報をXY座標に変換する
                            ColorImagePoint point = kinect.CoordinateMapper.MapSkeletonPointToColorPoint(join.Position, ColorImageFormat.RgbResolution640x480Fps30);

                            // 変換した座標を取得
                            skeletonPosition2D[jointIndex].X = point.X;
                            skeletonPosition2D[jointIndex].Y = point.Y;

                            // Kinectから取得したデータを取得
                            // （取得できるのはKinectから見た相対座標）
                            skeletonPosition3D[jointIndex].X = join.Position.X;
                            skeletonPosition3D[jointIndex].Y = join.Position.Y;
                            skeletonPosition3D[jointIndex].Z = join.Position.Z;

                            // 次に取得する骨格の箇所
                            jointIndex++;
                        }
                    }
                }

                // skeletonFrameを削除
                skeletonFrame.Dispose();
            }
        }

        /// <summary>
        /// byte配列データをBitmapに変換
        /// </summary>
        /// <param name="pixels">kinectで取得したbyte[]配列データ</param>
        /// <param name="width">横サイズ</param>
        /// <param name="height">縦サイズ</param>
        /// <returns></returns>
        private static Bitmap toBitmap(byte[] pixels, int width, int height)
        {
            // pixelsに何も入っていない場合nullを返す
            if (pixels == null)
                return null;

            // ビットマップの初期化
            var bitmap = new Bitmap(width, height, PixelFormat.Format32bppRgb);

            // システムメモリへロック
            var data = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadWrite, bitmap.PixelFormat);

            // メモリデータのコピー
            Marshal.Copy(pixels, 0, data.Scan0, pixels.Length);

            // システムメモリのロック解除
            bitmap.UnlockBits(data);

            return bitmap;
        }

        /// <summary>
        /// 深度ごとに色づけ&認識ユーザーの色づけ
        /// </summary>
        private void ConvertDepthFrame(short[] depthFrame, DepthImageStream depthStream)
        {
            int tooNearDepth = depthStream.TooNearDepth;
            int tooFarDepth = depthStream.TooFarDepth;
            int unknownDepth = depthStream.UnknownDepth;

            for (int i16 = 0, i32 = 0; i16 < depthFrame.Length && i32 < this.depthImageData.Length; i16++, i32 += 4)
            {
                int player = depthFrame[i16] & DepthImageFrame.PlayerIndexBitmask;
                int realDepth = depthFrame[i16] >> DepthImageFrame.PlayerIndexBitmaskWidth;

                // 13ビットの深度情報を表示に適した8ビットへ変換する（最上位ビットを無視する）らしい・・・
                byte intensity = (byte)(~(realDepth >> 4));

                if (player == 0 && realDepth == 0)
                {
                    // 白色
                    // 40～80cmの間（近すぎ）
                    depthImageData[i32 + RedIndex] = 255;
                    depthImageData[i32 + GreenIndex] = 255;
                    depthImageData[i32 + BlueIndex] = 255;
                }
                else if (player == 0 && realDepth == tooFarDepth)
                {
                    // 紫色
                    // 5m以上を意味する？（遠すぎる？）
                    depthImageData[i32 + RedIndex] = 66;
                    depthImageData[i32 + GreenIndex] = 0;
                    depthImageData[i32 + BlueIndex] = 66;
                }
                else if (player == 0 && realDepth == unknownDepth)
                {
                    // 茶色
                    // 赤外線投影機と赤外線認識カメラのずれで認識できない範囲？
                    depthImageData[i32 + RedIndex] = 66;
                    depthImageData[i32 + GreenIndex] = 66;
                    depthImageData[i32 + BlueIndex] = 33;
                }
                else
                {
                    // 認識ユーザーごとに色をつける
                    depthImageData[i32 + RedIndex] = (byte)(intensity >> PlayerR[player]);
                    depthImageData[i32 + GreenIndex] = (byte)(intensity >> PlayerG[player]);
                    depthImageData[i32 + BlueIndex] = (byte)(intensity >> PlayerB[player]);
                }
            }
        }
    }
}
