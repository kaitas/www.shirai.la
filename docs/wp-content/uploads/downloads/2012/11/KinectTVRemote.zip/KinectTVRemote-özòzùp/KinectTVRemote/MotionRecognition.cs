﻿using System.IO;
using AccuMotion;

namespace KinectTVRemote
{
    
    #region -- enum --

    /// <summary>
    /// ポーズの種類
    /// </summary>
    public enum MotionType
    {
        /// <summary>
        /// 右手を胸の前に突き出す
        /// </summary>
        HandKeep,

        /// <summary>
        /// HandKeepの状態から、右手を上に移動させる
        /// </summary>
        HandUp,

        /// <summary>
        /// HandKeepの状態から、右手を右に移動させる
        /// </summary>
        HandRight,

        /// <summary>
        /// HandKeepの状態から、右手を下に移動させる
        /// </summary>
        HandDown,

        /// <summary>
        /// HandKeepの状態から、右手を左に移動させる
        /// </summary>
        HandLeft,

        /// <summary>
        /// 何もしていない
        /// </summary>
        None
    }

    #endregion
    
    /// <summary>
    /// 姿勢の状態を認識
    /// </summary>
    public class MotionRecognition
    {
        /// <summary>
        /// 読み込むファイル名
        /// </summary>
        private string[] FileName = { "handKeepMotion.csv", "handUpMotion.csv", "handRightMotion.csv", "handDownMotion.csv", "handLeftMotion.csv" };

        /// <summary>
        /// 1つのベクトルを生成するために必要な2つの骨格情報の箇所
        /// </summary>
        private int[,] makeVectorPosition = new int[4,2];

        /// <summary>
        /// 認識人物の骨格ベクトル
        /// </summary>
        private Vector3[] playerVector = new Vector3[4];

        /// <summary>
        /// 保存しておいた姿勢の骨格ベクトル
        /// </summary>
        private Vector3[,] targetVector;

        /// <summary>
        /// 評価関数によって求められた、各モーション後のと類似度を格納
        /// </summary>
        public int[] evaluationValue;
        
        /// <summary>
        /// 現在の姿勢状態
        /// </summary>
        public MotionType motionType = MotionType.None;

        /// <summary>
        /// どれくらい同じポーズをとっていたか
        /// </summary>
        public int keepCounter = 0;

        ///////////////////////////////////////

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public MotionRecognition()
        {
            // targetvectorの初期化
            targetVector = new Vector3[FileName.Length, 4];
   
            // evaluationValueの初期化
            evaluationValue = new int[FileName.Length];
        }

        /// <summary>
        /// すべてのファイルを読み込み
        /// </summary>
        public void AllLoadFile()
        {
            using (StreamReader reader = new StreamReader("../../MotionFile/makeVector.csv"))
            {
                // ベクトル数(4本)分、読み込みを行う
                for (int i = 0; i < 4; i++)
                {
                    // 文字列の読み込み
                    string line = reader.ReadLine();

                    // カンマで分割してbuffer配列に保存
                    string[] buffer = line.Split(new char[] { ',' });

                    // intに変換してデータを取得
                    makeVectorPosition[i, 0] = int.Parse(buffer[0]);
                    makeVectorPosition[i, 1] = int.Parse(buffer[1]);
                }

                // StreamReaderを閉じる
                reader.Close();
            }

            // 姿勢数分のファイルを読み込む
            for (int i = 0; i < FileName.Length; i++)
            {
                // ファイルを開く
                OneLoadFile(i);
            }
        }

        /// <summary>
        /// 姿勢ベクトルのファイルを1つ読み込む
        /// </summary>
        private void OneLoadFile(int loadFileNo)
        {
            // ファイルを開く
            using (StreamReader reader = new StreamReader("../../MotionFile/" + FileName[loadFileNo].ToString()))
            {
                // ベクトル数(4本)分、読み込みを行う
                for (int i = 0; i < 4; i++)
                {
                    // 文字列の読み込み
                    string line = reader.ReadLine();

                    // カンマで分割してbuffer配列に保存
                    string[] buffer = line.Split(new char[] { ',' });

                    // floatに変換してデータを取得
                    targetVector[loadFileNo, i].X = float.Parse(buffer[0]);
                    targetVector[loadFileNo, i].Y = float.Parse(buffer[1]);
                    targetVector[loadFileNo, i].Z = float.Parse(buffer[2]);
                }

                // StreamReaderを閉じる
                reader.Close();
            }
        }

        /// <summary>
        /// ファイルの保存
        /// </summary>
        /// <param name="SaveFileNo">保存するファイル　0:HnadKeep 1:HandUp 2:HandRight 3:HandDown 4:HnadLeft</param>
        public void SaveFile(int SaveFileNo)
        {
            // ファイルを作成してデータを書き込む
            using (StreamWriter writer = new StreamWriter("../../MotionFile/" + FileName[SaveFileNo].ToString()))
            {
                // 骨格ベクトルの書き込み
                for (int i = 0; i < playerVector.Length; i++)
                    writer.WriteLine(playerVector[i].X.ToString() + "," + playerVector[i].Y.ToString() + "," + playerVector[i].Z.ToString());

                // ファイルを閉じる
                writer.Close();
            }

            // ファイルを再読み込みして認識に即反映させる
            OneLoadFile(SaveFileNo);
        }

        /// <summary>
        /// 毎フレーム更新する処理
        /// </summary>
        /// <param name="skeletonPosition3D">skeletonPosition3Dを受け渡す</param>
        /// <param name="keepThreshold">HnadKeepのtrackBarの値</param>
        /// <param name="upThreshold">HnadUpのtrackBarの値</param>
        /// <param name="rightThreshold">HnadRightのtrackBarの値</param>
        /// <param name="downThreshold">HnadDownのtrackBarの値</param>
        /// <param name="leftThreshold">HnadLeftのtrackBarの値</param>
        public void Update(Vector3[] skeletonPosition3D, int keepThreshold, int upThreshold, int rightThreshold, int downThreshold, int leftThreshold, int keepTime)
        {
            // 今回必要なベクトルは腕だけなので4つで済む
            for (int i = 0; i < 4; i++)
            {
                // Kinectから得た座標情報からベクトルを求める
                playerVector[i] = Algorithm.VectorMath(skeletonPosition3D[makeVectorPosition[i, 0]], skeletonPosition3D[makeVectorPosition[i, 1]]);
            }

            // 認識した骨格ベクトルと姿勢骨格ベクトルを比較
            evaluationValue[(int)MotionType.HandKeep] = Algorithm.EvaluationFunction(playerVector, targetVector, (int)MotionType.HandKeep);
            evaluationValue[(int)MotionType.HandUp] = Algorithm.EvaluationFunction(playerVector, targetVector, (int)MotionType.HandUp);
            evaluationValue[(int)MotionType.HandRight] = Algorithm.EvaluationFunction(playerVector, targetVector, (int)MotionType.HandRight);
            evaluationValue[(int)MotionType.HandDown] = Algorithm.EvaluationFunction(playerVector, targetVector, (int)MotionType.HandDown);
            evaluationValue[(int)MotionType.HandLeft] = Algorithm.EvaluationFunction(playerVector, targetVector, (int)MotionType.HandLeft);

            switch (motionType)
            {
                case MotionType.None:

                    // keepThresholdと比較しevaluationValueの値が大きかったら対応した動作をしていると認識する
                    // カウンタを増加
                    if (evaluationValue[(int)MotionType.HandKeep] > keepThreshold)
                        keepCounter++;

                    if (keepCounter > keepTime)
                    {
                        motionType = MotionType.HandKeep;
                        keepCounter = 0;
                    }
                    break;

                case MotionType.HandKeep:

                    // それぞれの姿勢と比較しevaluationValueの値が大きかったら対応した動作をしていると認識する
                    if (evaluationValue[(int)MotionType.HandUp] > upThreshold)
                        motionType = MotionType.HandUp;

                    if (evaluationValue[(int)MotionType.HandRight] > rightThreshold)
                        motionType = MotionType.HandRight;

                    if (evaluationValue[(int)MotionType.HandDown] > downThreshold)
                        motionType = MotionType.HandDown;

                    if (evaluationValue[(int)MotionType.HandLeft] > leftThreshold)
                        motionType = MotionType.HandLeft;

                    break;

                case MotionType.HandUp:
                case MotionType.HandRight:
                case MotionType.HandDown:
                case MotionType.HandLeft:

                    // カウンタを増加
                    keepCounter++;

                    // 状態を戻す
                    if (keepCounter > keepTime)
                    {
                        motionType = MotionType.None;
                        keepCounter = 0;
                    }
                    break;

                default:
                    break;

            }
        }
    }
}
